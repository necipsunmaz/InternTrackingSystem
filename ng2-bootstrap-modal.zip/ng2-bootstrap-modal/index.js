Object.defineProperty(exports, "__esModule", { value: true });
var bootstrap_modal_module_1 = require('./dist/index');
exports.BootstrapModalModule = bootstrap_modal_module_1.BootstrapModalModule;
exports.DialogComponent = bootstrap_modal_module_1.DialogComponent;
exports.DialogService = bootstrap_modal_module_1.DialogService;