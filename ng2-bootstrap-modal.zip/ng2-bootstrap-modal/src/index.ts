export { BootstrapModalModule } from './bootstrap-modal.module';
export { DialogComponent } from './dialog.component';
export { DialogService, DialogOptions, DialogServiceConfig } from './dialog.service';